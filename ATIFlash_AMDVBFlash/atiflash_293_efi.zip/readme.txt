******************************************************************************
* AMD Radeon VBIOS EFI Flashing Shell v1.0 by W1zzard at www.techpowerup.com *
******************************************************************************

This EFI-shell based flashing package lets you flash the BIOS on your AMD 
Radeon Graphics card without the need to create a bootable DOS USB stick.

1) Format a USB stick with FAT32
2) Copy all files in this archive to the root directory of the USB stick
3) Copy your BIOS file to the root directory of the USB stick
4) Make sure "Fast Startup" is disabled in your BIOS
5) Check that the USB UEFI drive is listed and activated in BIOS boot devices
6) Reboot, your system should start from the USB stick, showing a command prompt

If you still can't boot from USB, try pressing F12 or F9 to invoke the boot menu and select the UEFI USB option from there.